from PyQt5.QtWidgets import QVBoxLayout, QLineEdit, QLabel, QWidget, QHBoxLayout, QPushButton


def InputWidget(label, type=QLineEdit.Normal, validator=None):
    widget = QWidget()
    box = QVBoxLayout()
    label = QLabel(label)
    input = QLineEdit()
    input.setEchoMode(type)
    if validator:
        input.setValidator(validator)
    box.addWidget(label)
    box.addWidget(input)
    box.addStretch()
    widget.setLayout(box)
    widget.text = input.text
    return widget


def SelectWidget(label):
    widget = QWidget()
    box = QVBoxLayout()
    label = QLabel(label)
    box.addWidget(label)
    box.addStretch()
    widget.setLayout(box)
    return widget


def ShellWidget(navbar_options, content, on_navbar_change=None, logout=None):
    widget = QWidget()
    box = QHBoxLayout()
    navbar = QVBoxLayout()
    for option in navbar_options:
        button = QPushButton(option)
        button.clicked.connect(lambda x, opt=option: on_navbar_change(opt))
        navbar.addWidget(button)

    if logout:
        logout_button = QPushButton('Çıkış')
        logout_button.clicked.connect(logout)
        navbar.addWidget(logout_button)

    box.addLayout(navbar)
    box.addWidget(content)
    widget.setLayout(box)
    return widget

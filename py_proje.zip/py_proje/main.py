from PyQt5 import QtGui
from PyQt5.QtWidgets import QApplication, QStackedWidget
from PyQt5.QtGui import QIcon

from pages import login_page_widget
from style import style_sheet

if __name__ == '__main__':
    app = QApplication([])

    font = QtGui.QFont("Arial", 10)
    app.setFont(font)

    stack = QStackedWidget()
    stack.setWindowTitle('HealthMate')

    stack.setWindowIcon(QIcon(r'C:\Users\Buket BORAN\Downloads\healthcare.png'))

    stack.setObjectName("mainStack")
    stack.setStyleSheet(style_sheet)

    pageWidget = login_page_widget(stack)
    stack.setFixedSize(pageWidget.sizeHint())

    stack.addWidget(pageWidget)
    stack.show()






    app.exec_()

USE healthmate;

INSERT INTO user (username, password, email, firstname, lastname, role) VALUES
('aliyilmaz', SHA2('YilmazSaglik2023', 256), 'aliyilmaz@example.com', 'Ali', 'Yılmaz', 'HEALTHCAREPROVIDER'),
('aysegulozkan', SHA2('OzkanSaglik2024', 256), 'aysegulozkan@example.com', 'Ayşe', 'Özkan', 'HEALTHCAREPROVIDER'),
('ahmetyildirim', SHA2('Ahmet123Yildirim!', 256), 'ahmetyildirim@example.com', 'Ahmet', 'Yıldırım', 'USER'),
('banucetin', SHA2('BanuPassword!23', 256), 'banucetin@example.com', 'Banu', 'Çetin', 'USER'),
('cemaletunc', SHA2('CemalHarika2023!', 256), 'cemaletunc@example.com', 'Cemal', 'Ertunç', 'USER'),
('denizdemir', SHA2('DenizGüzelDeniz', 256), 'denizdemir@example.com', 'Deniz', 'Demir', 'USER'),
('elifakgun', SHA2('AkgunGizli2024', 256), 'elifakgun@example.com', 'Elif', 'Akgün', 'USER'),
('ferhatozdemir', SHA2('OzdemirKral2023', 256), 'ferhatozdemir@example.com', 'Ferhat', 'Özdemir', 'USER'),
('gulserenkaya', SHA2('Gulseren123Kaya!', 256), 'gulserenkaya@example.com', 'Gülseren', 'Kaya', 'USER'),
('hakankara', SHA2('HakanKara2023$', 256), 'hakankara@example.com', 'Hakan', 'Kara', 'USER');

INSERT INTO user_provider (user_id, provider_id)
VALUES (3, 1),
       (4, 1),
       (5, 1),
       (6, 2),
       (7, 2),
       (8, 2),
       (9, 1),
       (10, 2);

INSERT INTO notes (user_id, note)
VALUES
    (3, 'Son iki gündür hafif yorgunluk ve baş ağrısı hissediyorum.'),
    (4, 'Belimde yineleyen ağrı hissediyorum. Tavsiye edilen şekilde hafif ağrı kesici alıyorum.'),
    (5, 'Soğuk algınlığı belirtilerim var: burun akıntısı ve boğaz ağrısı.'),
    (6, 'İlaçlarımı aldıktan sonra mide bulantısı ve baş dönmesi yaşadım.'),
    (7, 'Sürekli olarak endişeli hissediyorum ve ara sıra baş dönmesi yaşıyorum.'),
    (8, 'Grip belirtilerim var. Ateş, titreme, kas ağrıları, öksürük ve tıkanıklık.'),
    (9, 'Uyumakta zorluk çekiyorum ve dinlenmiş hissetmiyorum. İnsomnia hastalığım olabilir.'),
    (10, 'Egzersiz sırasında nefes darlığı ve hafif göğüs ağrısı yaşadım.');

INSERT INTO medication (user_id, medication, dosage)
VALUES
    (3, 'Amoksisilin', 500),
    (4, 'İbuprofen', 200),
    (5, 'Loratadin', 10),
    (6, 'Parasetamol', 500),
    (7, 'Lisinopril', 10),
    (8, 'Oseltamivir', 75),
    (9, 'Melatonin', 5),
    (10, 'Metoprolol', 50);


INSERT INTO blood_pressure (user_id, systolic, diastolic)
VALUES
    (3, 121, 78),
    (4, 123, 86),
    (5, 132, 89),
    (6, 116, 74),
    (7, 112, 72),
    (8, 134, 87),
    (9, 139, 91),
    (10, 124, 76);

INSERT INTO heart_rate (user_id, heart_rate)
VALUES
    (3, 67),
    (4, 72),
    (5, 95),
    (6, 66),
    (7, 63),
    (8, 84),
    (9, 113),
    (10, 73);

INSERT INTO blood_sugar (user_id, blood_sugar)
VALUES
    (3, 87),
    (4, 134),
    (5, 90),
    (6, 111),
    (7, 123),
    (8, 98),
    (9, 146),
    (10, 104);

INSERT INTO weight (user_id, weight)
VALUES
    (3, 66),
    (4, 72),
    (5, 83),
    (6, 87),
    (7, 98),
    (8, 84),
    (9, 76),
    (10, 94);
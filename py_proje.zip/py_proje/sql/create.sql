CREATE DATABASE IF NOT EXISTS healthmate CHARACTER SET utf8;
USE healthmate;

CREATE TABLE user
(
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    firstname VARCHAR(255) NOT NULL,
    lastname VARCHAR(255) NOT NULL,
    role ENUM('USER', 'HEALTHCAREPROVIDER', 'ADMIN') NOT NULL DEFAULT 'USER'
);

CREATE TABLE user_provider
(
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    provider_id INT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES user(id),
    FOREIGN KEY (provider_id) REFERENCES user(id)
);

CREATE TABLE notes
(
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    note TEXT NOT NULL,
    date DATETIME NOT NULL DEFAULT NOW(),
    FOREIGN KEY (user_id) REFERENCES user(id)
);

CREATE TABLE medication
(
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    medication NVARCHAR(100) NOT NULL,
    dosage INT NOT NULL,
    date DATETIME NOT NULL DEFAULT NOW(),
    FOREIGN KEY (user_id) REFERENCES user(id)
);

CREATE TABLE blood_pressure
(
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    systolic INT NOT NULL,
    diastolic INT NOT NULL,
    date DATETIME NOT NULL DEFAULT NOW(),
    FOREIGN KEY (user_id) REFERENCES user(id)
);

CREATE TABLE heart_rate
(
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    heart_rate INT NOT NULL,
    date DATETIME NOT NULL DEFAULT NOW(),
    FOREIGN KEY (user_id) REFERENCES user(id)
);

CREATE TABLE blood_sugar
(
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    blood_sugar INT NOT NULL,
    date DATETIME NOT NULL DEFAULT NOW(),
    FOREIGN KEY (user_id) REFERENCES user(id)
);

CREATE TABLE weight
(
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    weight INT NOT NULL,
    date DATETIME NOT NULL DEFAULT NOW(),
    FOREIGN KEY (user_id) REFERENCES user(id)
);

CREATE TABLE notification
(
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    type NVARCHAR(100) NOT NULL,
    message VARCHAR(255) NOT NULL,
    is_read BOOLEAN NOT NULL DEFAULT FALSE,
    date DATETIME NOT NULL DEFAULT NOW(),
    FOREIGN KEY (user_id) REFERENCES user(id)
);

CREATE TRIGGER heart_rate_after_insert
    AFTER INSERT
    ON heart_rate
    FOR EACH ROW
BEGIN
    IF NEW.heart_rate > 100 THEN
        INSERT INTO notification(user_id, type, message)
        VALUES (NEW.user_id, 'heart_rate_high_alert', CONCAT('Your heart rate of ', NEW.heart_rate, ' is too high.'));
    END IF;
END;

CREATE TRIGGER blood_pressure_after_insert
    AFTER INSERT
    ON blood_pressure
    FOR EACH ROW
BEGIN
    IF NEW.systolic > 140 OR NEW.diastolic > 90 THEN
        INSERT INTO notification(user_id, type, message)
        VALUES (NEW.user_id, 'blood_pressure_high_alert',
                CONCAT('Your blood pressure of ', NEW.systolic, '/', NEW.diastolic, ' is too high.'));
    END IF;
END;

CREATE TRIGGER blood_sugar_after_insert
    AFTER INSERT
    ON blood_sugar
    FOR EACH ROW
BEGIN
    IF NEW.blood_sugar > 120 THEN
        INSERT INTO notification(user_id, type, message)
        VALUES (NEW.user_id, 'blood_sugar_high_alert',
                CONCAT('Your blood sugar of ', NEW.blood_sugar, ' is too high.'));
    END IF;
END;

CREATE PROCEDURE register(IN username VARCHAR(255), IN password VARCHAR(255), IN email VARCHAR(255),
                          IN firstname VARCHAR(255), IN lastname VARCHAR(255), IN role ENUM('USER', 'HEALTHCAREPROVIDER', 'ADMIN'))
BEGIN
    INSERT INTO user(username, password, email, firstname, lastname, role)
    VALUES (username, sha2(password, 256), email, firstname, lastname, role);
END;

CREATE PROCEDURE login(IN username VARCHAR(255), IN password VARCHAR(255))
BEGIN
    SELECT * FROM user WHERE user.username = username AND user.password = sha2(password, 256) LIMIT 1;
END;

CREATE PROCEDURE get_user_providers(IN provider_id INT)
BEGIN
    SELECT u.*
    FROM user AS u
             INNER JOIN user_provider up ON u.id = up.provider_id
    WHERE up.user_id = provider_id;
END;

CREATE PROCEDURE get_provider_users(IN user_id INT)
BEGIN
    SELECT u.*
    FROM user AS u
             INNER JOIN user_provider up ON u.id = up.user_id
    WHERE up.provider_id = user_id;
END;

CREATE PROCEDURE get_user_blood_pressures(IN user_id INT)
BEGIN
    SELECT *
    FROM blood_pressure
    WHERE blood_pressure.user_id = user_id
    ORDER BY date DESC;
END;

CREATE PROCEDURE last_week_average_blood_pressure(IN user_id INT)
BEGIN
    SELECT AVG(systolic) AS systolic, AVG(diastolic) AS diastolic
    FROM blood_pressure
    WHERE blood_pressure.user_id = user_id
      AND date >= DATE_SUB(NOW(), INTERVAL 1 WEEK);
END;

CREATE PROCEDURE get_all_average_blood_pressure()
BEGIN
    SELECT blood_pressure.user_id, AVG(systolic) AS systolic, AVG(diastolic) AS diastolic
    FROM blood_pressure
    GROUP BY blood_pressure.user_id;
END;

CREATE PROCEDURE get_users_with_high_blood_pressure()
BEGIN
    SELECT user.id, AVG(blood_pressure.systolic) AS systolic, AVG(blood_pressure.diastolic) AS diastolic
    FROM user
             INNER JOIN blood_pressure ON user.id = blood_pressure.user_id
    GROUP BY user.id
    HAVING AVG(blood_pressure.systolic) > 140
        OR AVG(blood_pressure.diastolic) > 90;
END;

CREATE PROCEDURE get_users_with_pre_high_blood_pressure_alternative()
BEGIN
    SELECT user.*
    FROM user
    WHERE user.id IN (SELECT blood_pressure.user_id
                      FROM blood_pressure
                      GROUP BY blood_pressure.user_id
                      HAVING AVG(blood_pressure.systolic) BETWEEN 120 AND 139
                          OR AVG(blood_pressure.diastolic) BETWEEN 80 AND 89);
END;

CREATE PROCEDURE add_blood_pressure_reading(IN user_id INT, IN systolic INT, IN diastolic INT)
BEGIN
    INSERT INTO blood_pressure(user_id, systolic, diastolic)
    VALUES (user_id, systolic, diastolic);
END;

CREATE PROCEDURE get_blood_pressure_type(IN blood_pressure_id INT)
BEGIN
    SELECT CASE
               WHEN systolic > 140 OR diastolic > 90 THEN 'high'
               WHEN systolic BETWEEN 120 AND 139 OR diastolic BETWEEN 80 AND 89 THEN 'pre-high'
               WHEN systolic < 90 OR diastolic < 60 THEN 'low'
               ELSE 'normal'
               END AS type
    FROM blood_pressure
    WHERE blood_pressure.id = blood_pressure_id;
END;

CREATE PROCEDURE get_user_heart_rates(IN user_id INT)
BEGIN
    SELECT *
    FROM heart_rate
    WHERE heart_rate.user_id = user_id
    ORDER BY date DESC;
END;

CREATE PROCEDURE last_week_average_heart_rate(IN user_id INT)
BEGIN
    SELECT AVG(heart_rate) AS heart_rate
    FROM heart_rate
    WHERE heart_rate.user_id = user_id
      AND date >= DATE_SUB(NOW(), INTERVAL 1 WEEK);
END;

CREATE PROCEDURE get_all_average_heart_rate()
BEGIN
    SELECT heart_rate.user_id, AVG(heart_rate) AS heart_rate
    FROM heart_rate
    GROUP BY heart_rate.user_id;
END;

CREATE PROCEDURE add_heart_rate_reading(IN user_id INT, IN heart_rate INT)
BEGIN
    INSERT INTO heart_rate(user_id, heart_rate)
    VALUES (user_id, heart_rate);
END;

CREATE PROCEDURE get_user_blood_sugars(IN user_id INT)
BEGIN
    SELECT *
    FROM blood_sugar
    WHERE blood_sugar.user_id = user_id
    ORDER BY date DESC;
END;

CREATE PROCEDURE last_week_average_blood_sugar(IN user_id INT)
BEGIN
    SELECT AVG(blood_sugar) AS blood_sugar
    FROM blood_sugar
    WHERE blood_sugar.user_id = user_id
      AND date >= DATE_SUB(NOW(), INTERVAL 1 WEEK);
END;

CREATE PROCEDURE get_all_average_blood_sugar()
BEGIN
    SELECT blood_sugar.user_id, AVG(blood_sugar) AS blood_sugar
    FROM blood_sugar
    GROUP BY blood_sugar.user_id;
END;

CREATE PROCEDURE add_blood_sugar_reading(IN user_id INT, IN blood_sugar INT)
BEGIN
    INSERT INTO blood_sugar(user_id, blood_sugar)
    VALUES (user_id, blood_sugar);
END;

CREATE PROCEDURE get_user_notifications_by_type(IN user_id INT, IN type NVARCHAR(100))
BEGIN
    SELECT *
    FROM notification
    WHERE notification.user_id = user_id
      AND notification.type like CONCAT('%', type, '%')
    ORDER BY date DESC;
END;

CREATE PROCEDURE get_user_new_notification_count(IN user_id INT)
BEGIN
    SELECT COUNT(*) AS count
    FROM notification
    WHERE notification.user_id = user_id
      AND notification.is_read = FALSE;
END;

CREATE PROCEDURE mark_user_notifications_as_read(IN user_id INT)
BEGIN
    UPDATE notification
    SET notification.is_read = TRUE
    WHERE notification.user_id = user_id
      AND notification.is_read = FALSE;
END;

CREATE PROCEDURE get_user_notes(IN user_id INT)
BEGIN
    SELECT *
    FROM notes
    WHERE notes.user_id = user_id
    ORDER BY date DESC;
END;

CREATE PROCEDURE add_note(IN user_id INT, IN note TEXT)
BEGIN
    INSERT INTO notes(user_id, note)
    VALUES (user_id, note);
END;

CREATE PROCEDURE get_all_followed_user_notes(IN user_id INT)
BEGIN
    SELECT n.*
    FROM notes AS n
             INNER JOIN user_provider up ON n.user_id = up.user_id
    WHERE up.provider_id = user_id
    ORDER BY date DESC;
END;

CREATE PROCEDURE get_user_weight(IN user_id INT)
BEGIN
    SELECT *
    FROM weight
    WHERE weight.user_id = user_id
    ORDER BY date DESC;
END;

CREATE PROCEDURE add_weight_reading(IN user_id INT, IN weight INT)
BEGIN
    INSERT INTO weight(user_id, weight)
    VALUES (user_id, weight);
END;

CREATE PROCEDURE get_user_medications(IN user_id INT)
BEGIN
    SELECT *
    FROM medication
    WHERE medication.user_id = user_id
    ORDER BY date DESC;
END;

create procedure add_medication(IN user_id INT, IN medication NVARCHAR(100), IN dosage INT)
BEGIN
    INSERT INTO medication(user_id, medication, dosage)
    VALUES (user_id, medication, dosage);
END;

from PyQt5.QtGui import QIntValidator, QIcon, QColor
from PyQt5.QtWidgets import QPushButton, QVBoxLayout, QWidget, QLineEdit, QDialog, QLabel, QStackedWidget, QTableWidget, \
    QTableWidgetItem
from mysql.connector import Error

from components import InputWidget, SelectWidget, ShellWidget
from database import login, register, get_user_heart_rates, get_user_blood_sugars, \
    get_user_blood_pressures, get_user_weight, get_user_notes, add_blood_pressure, add_heart_rate, add_blood_sugar, \
    add_weight, add_user_notes
from style import style_sheet


def open_register_dialog():
    dialog = QDialog()
    dialog.setWindowTitle('Kaydol')
    dialog.setObjectName('dialogStack')
    dialog.setStyleSheet(style_sheet)
    dialog.setWindowIcon(QIcon(r'C:\Users\Buket BORAN\Downloads\healthcare.png'))
    widget = register_page_widget(dialog)
    box = QVBoxLayout()
    box.addWidget(widget)
    dialog.setLayout(box)
    dialog.exec_()


def open_invalid_credentials_dialog():
    dialog = QDialog()
    dialog.setWindowTitle('Hatalı Giriş')

    dialog.setObjectName('dialogStack')
    dialog.setStyleSheet(style_sheet)
    box = QVBoxLayout()
    label = QLabel('Hatalı Giriş')
    box.addWidget(label)
    dialog.setLayout(box)
    dialog.exec_()


def exec_logout(stack):
    widget = login_page_widget(stack)
    for i in range(stack.count()):
        stack.removeWidget(stack.widget(i))
    stack.addWidget(widget)
    stack.setCurrentWidget(widget)
    stack.setFixedSize(widget.sizeHint())


def exec_login(username, password, stack):
    result = login(password, username)
    if result is None:
        open_invalid_credentials_dialog()
    else:
        user = {
            'id': result[0],
            'username': result[1],
            'password': result[2],
            'email': result[3],
            'firstname': result[4],
            'lastname': result[5]
        }
        set_main_widget(stack, user)


def set_main_widget(stack, user, page=0):
    widget = main_page_widget(stack, user, page)
    for i in range(stack.count()):
        stack.removeWidget(stack.widget(i))
    stack.addWidget(widget)
    stack.setCurrentWidget(widget)
    stack.setFixedSize(600, 200)


def exec_register(username, password, email, firstname, lastname, dialog):
    if username == '' or password == '' or email == '' or firstname == '' or lastname == '':
        return

    try:
        register(email, firstname, lastname, password, username)
        dialog.close()
    except Error as e:
        print(f"Error: {e}")


def login_page_widget(stack):
    widget = QWidget()
    box = QVBoxLayout()

    username = InputWidget('Kullanıcı Adı')
    password = InputWidget('Şifre', QLineEdit.Password)

    login_button = QPushButton('Giriş Yap')
    login_button.clicked.connect(lambda: exec_login(username.text(), password.text(), stack))

    register_button = QPushButton('Kaydol')
    register_button.clicked.connect(open_register_dialog)

    box.addWidget(username)
    box.addWidget(password)
    box.addWidget(login_button)
    box.addWidget(register_button)

    widget.setLayout(box)
    return widget


def register_page_widget(dialog):
    widget = QWidget()
    box = QVBoxLayout()

    username = InputWidget('Kullanıcı Adı')
    password = InputWidget('Şifre', QLineEdit.Password)
    email = InputWidget('Email')
    firstname = InputWidget('Ad')
    lastname = InputWidget('Soyad')

    register_button = QPushButton('Kaydol')
    register_button.clicked.connect(
        lambda: exec_register(username.text(), password.text(), email.text(), firstname.text(), lastname.text(),
                              'USER', dialog))

    box.addWidget(username)
    box.addWidget(password)
    box.addWidget(email)
    box.addWidget(firstname)
    box.addWidget(lastname)
    box.addWidget(register_button)

    widget.setLayout(box)

    return widget


def navbar_change(name, stack):
    if name == 'Tansiyon':
        stack.setCurrentIndex(0)
    elif name == 'Kalp Ritmi':
        stack.setCurrentIndex(1)
    elif name == 'Kan Şekeri':
        stack.setCurrentIndex(2)
    elif name == 'Kilo':
        stack.setCurrentIndex(3)
    elif name == 'Notlar':
        stack.setCurrentIndex(4)


def main_page_widget(main_stack, user, page=0):
    blood_pressures = get_user_blood_pressures(user['id'])
    blood_sugars = get_user_blood_sugars(user['id'])
    heart_rates = get_user_heart_rates(user['id'])
    weight = get_user_weight(user['id'])
    notes = get_user_notes(user['id'])

    stack = QStackedWidget()

    stack.addWidget(blood_pressure_page_widget(main_stack, user, blood_pressures))
    stack.addWidget(heart_rate_page_widget(main_stack, user, heart_rates))
    stack.addWidget(blood_sugar_page_widget(main_stack, user, blood_sugars))
    stack.addWidget(weight_page_widget(main_stack, user, weight))
    stack.addWidget(notes_page_widget(main_stack, user, notes))

    stack.setCurrentIndex(page)

    shell = ShellWidget(['Tansiyon', 'Kalp Ritmi', 'Kan Şekeri', 'Kilo', 'Notlar'], stack,
                        lambda name: navbar_change(name, stack),
                        lambda: exec_logout(main_stack))

    return shell


def exec_add_blood_pressure(stack, user, sis, dia, dialog):
    if sis == '' or dia == '':
        return

    try:
        add_blood_pressure(user['id'], sis, dia)
        dialog.close()
        set_main_widget(stack, user, 0)
    except Error as e:
        print(f"Error: {e}")


def exec_add_blood_sugar(stack, user, blood_sugar, dialog):
    if blood_sugar == '':
        return

    try:
        add_blood_sugar(user['id'], blood_sugar)
        dialog.close()
        set_main_widget(stack, user, 2)
    except Error as e:
        print(f"Error: {e}")


def exec_add_heart_rate(stack, user, heart_rate, dialog):
    if heart_rate == '':
        return

    try:
        add_heart_rate(user['id'], heart_rate)
        dialog.close()
        set_main_widget(stack, user, 1)
    except Error as e:
        print(f"Error: {e}")


def exec_add_weight(stack, user, weight, dialog):
    if weight == '':
        return

    try:
        add_weight(user['id'], weight)
        dialog.close()
        set_main_widget(stack, user, 3)
    except Error as e:
        print(f"Error: {e}")


def exec_add_user_notes(stack, user, notes, dialog):
    if notes == '':
        return

    try:
        add_user_notes(user['id'], notes)
        dialog.close()
        set_main_widget(stack, user, 4)
    except Error as e:
        print(f"Error: {e}")


def add_blood_pressure_dialog(stack, user):
    dialog = QDialog()
    dialog.setWindowTitle('Tansiyon Değeri')

    dialog.setObjectName('dialogStack')
    dialog.setStyleSheet(style_sheet)
    sis_input = InputWidget('Sistolik', validator=QIntValidator())
    dia_input = InputWidget('Diyastolik', validator=QIntValidator())
    submit_button = QPushButton('Ekle')

    submit_button.clicked.connect(
        lambda: exec_add_blood_pressure(stack, user, sis_input.text(), dia_input.text(), dialog))

    box = QVBoxLayout()
    box.addWidget(sis_input)
    box.addWidget(dia_input)
    box.addWidget(submit_button)

    dialog.setLayout(box)
    dialog.exec_()


def add_blood_sugar_dialog(stack, user):
    dialog = QDialog()
    dialog.setWindowTitle('Kan Şekeri Değeri')

    dialog.setObjectName('dialogStack')
    dialog.setStyleSheet(style_sheet)
    blood_sugar_input = InputWidget('Kan Şekeri', validator=QIntValidator())
    submit_button = QPushButton('Ekle')

    submit_button.clicked.connect(
        lambda: exec_add_blood_sugar(stack, user, blood_sugar_input.text(), dialog))

    box = QVBoxLayout()
    box.addWidget(blood_sugar_input)
    box.addWidget(submit_button)
    dialog.setLayout(box)
    dialog.exec_()


def add_heart_rate_dialog(stack, user):
    dialog = QDialog()
    dialog.setWindowTitle('Kalp Ritmi Değeri')

    dialog.setObjectName('dialogStack')
    dialog.setStyleSheet(style_sheet)
    heart_rate_input = InputWidget('Kalp Ritmi', validator=QIntValidator())
    submit_button = QPushButton('Ekle')

    submit_button.clicked.connect(
        lambda: exec_add_heart_rate(stack, user, heart_rate_input.text(), dialog))

    box = QVBoxLayout()
    box.addWidget(heart_rate_input)
    box.addWidget(submit_button)
    dialog.setLayout(box)
    dialog.exec_()


def add_weight_dialog(stack, user):
    dialog = QDialog()
    dialog.setWindowTitle('Kilo Değeri')

    dialog.setObjectName('dialogStack')
    dialog.setStyleSheet(style_sheet)
    weight_input = InputWidget('Kilo', validator=QIntValidator())
    submit_button = QPushButton('Ekle')

    submit_button.clicked.connect(
        lambda: exec_add_weight(stack, user, weight_input.text(), dialog))

    box = QVBoxLayout()
    box.addWidget(weight_input)
    box.addWidget(submit_button)
    dialog.setLayout(box)
    dialog.exec_()


def add_user_notes_dialog(stack, user):
    dialog = QDialog()
    dialog.setWindowTitle('Not Ekle')

    dialog.setObjectName('dialogStack')
    dialog.setStyleSheet(style_sheet)
    notes_input = InputWidget('Not')
    submit_button = QPushButton('Ekle')

    submit_button.clicked.connect(
        lambda: exec_add_user_notes(stack, user, notes_input.text(), dialog))

    box = QVBoxLayout()
    box.addWidget(notes_input)
    box.addWidget(submit_button)
    dialog.setLayout(box)
    dialog.exec_()


def blood_pressure_page_widget(stack, user, blood_pressures):
    widget = QWidget()
    box = QVBoxLayout()

    table = QTableWidget()

    table.setEditTriggers(QTableWidget.NoEditTriggers)

    table.setRowCount(len(blood_pressures))

    table.setColumnCount(4)

    table.setHorizontalHeaderLabels(['Tarih', 'Sistolik', 'Diyastolik', 'Sonuç'])

    for i, blood_pressure in enumerate(blood_pressures):
        table.setItem(i, 0, QTableWidgetItem(str(blood_pressure['date'])))
        table.setItem(i, 1, QTableWidgetItem(str(blood_pressure['systolic'])))
        table.setItem(i, 2, QTableWidgetItem(str(blood_pressure['diastolic'])))

        result_item = QTableWidgetItem()
        result = determine_blood_pressure_result(blood_pressure['systolic'], blood_pressure['diastolic'])

        result_item.setText(result)

        if result == 'Yüksek':
            result_item.setBackground(QColor('red'))
        elif result == 'Düşük':
            result_item.setBackground(QColor('yellow'))
        else:
            result_item.setBackground(QColor('green'))

        table.setItem(i, 3, result_item)

    add_blood_pressure_button = QPushButton('Tansiyon Değeri Ekle')
    add_blood_pressure_button.clicked.connect(
        lambda: add_blood_pressure_dialog(stack, user))

    box.addWidget(add_blood_pressure_button)
    box.addWidget(table)

    widget.setLayout(box)

    return widget


def determine_blood_pressure_result(systolic, diastolic):
    if systolic > 120 or diastolic > 80:
        return 'Yüksek'
    elif systolic < 90 or diastolic < 60:
        return 'Düşük'
    else:
        return 'Normal'


def heart_rate_page_widget(stack, user, heart_rates):
    widget = QWidget()
    box = QVBoxLayout()

    table = QTableWidget()
    table.setEditTriggers(QTableWidget.NoEditTriggers)

    table.setRowCount(len(heart_rates))

    table.setColumnCount(3)

    table.setHorizontalHeaderLabels(['Tarih', 'Kalp Ritmi', 'Sonuç'])

    for i, heart_rate in enumerate(heart_rates):
        table.setItem(i, 0, QTableWidgetItem(str(heart_rate['date'])))
        table.setItem(i, 1, QTableWidgetItem(str(heart_rate['heart_rate'])))

        result_item = QTableWidgetItem()
        result = determine_heart_rate_result(heart_rate['heart_rate'])

        result_item.setText(result)

        if result == 'Yüksek':
            result_item.setBackground(QColor('red'))
        elif result == 'Düşük':
            result_item.setBackground(QColor('yellow'))
        else:
            result_item.setBackground(QColor('green'))

        table.setItem(i, 2, result_item)

    add_heart_rate_button = QPushButton('Kalp Ritmi Değeri Ekle')
    add_heart_rate_button.clicked.connect(lambda: add_heart_rate_dialog(stack, user))

    box.addWidget(add_heart_rate_button)
    box.addWidget(table)

    widget.setLayout(box)

    return widget


def determine_heart_rate_result(heart_rate):
    if heart_rate > 100:
        return 'Yüksek'
    elif heart_rate < 60:
        return 'Düşük'
    else:
        return 'Normal'


def blood_sugar_page_widget(stack, user, blood_sugars):
    widget = QWidget()
    box = QVBoxLayout()

    table = QTableWidget()
    table.setEditTriggers(QTableWidget.NoEditTriggers)
    table.setRowCount(len(blood_sugars))
    table.setColumnCount(3)

    table.setHorizontalHeaderLabels(["Tarih", "Kan Şekeri", "Sonuç"])

    for i, blood_sugar in enumerate(blood_sugars):
        table.setItem(i, 0, QTableWidgetItem(str(blood_sugar['date'])))
        table.setItem(i, 1, QTableWidgetItem(str(blood_sugar['blood_sugar'])))

        result_item = QTableWidgetItem()
        result = determine_blood_sugar_result(blood_sugar['blood_sugar'])

        result_item.setText(result)


        if result == 'Yüksek':
            result_item.setBackground(QColor('red'))
        elif result == 'Düşük':
            result_item.setBackground(QColor('yellow'))
        else:
            result_item.setBackground(QColor('green'))

        table.setItem(i, 2, result_item)

    add_blood_sugar_button = QPushButton('Kan Şekeri Değeri Ekle')
    add_blood_sugar_button.clicked.connect(lambda: add_blood_sugar_dialog(stack, user))

    box.addWidget(add_blood_sugar_button)
    box.addWidget(table)

    widget.setLayout(box)
    return widget


def determine_blood_sugar_result(blood_sugar):
    if blood_sugar > 140:
        return 'Yüksek'
    elif blood_sugar < 70:
        return 'Düşük'
    else:
        return 'Normal'


def weight_page_widget(stack, user, weight):
    widget = QWidget()
    box = QVBoxLayout()

    table = QTableWidget()
    table.setEditTriggers(QTableWidget.NoEditTriggers)
    table.setRowCount(len(weight))
    table.setColumnCount(2)

    table.setHorizontalHeaderLabels(["Tarih", "Kilo"])

    for i, weight in enumerate(weight):
        table.setItem(i, 0, QTableWidgetItem(str(weight['date'])))
        table.setItem(i, 1, QTableWidgetItem(str(weight['weight'])))

    add_weight_button = QPushButton('Kilo Değeri Ekle')
    add_weight_button.clicked.connect(lambda: add_weight_dialog(stack, user))

    box.addWidget(add_weight_button)
    box.addWidget(table)

    widget.setLayout(box)
    return widget


def notes_page_widget(stack, user, notes):
    widget = QWidget()
    box = QVBoxLayout()

    table = QTableWidget()
    table.setEditTriggers(QTableWidget.NoEditTriggers)
    table.setRowCount(len(notes))
    table.setColumnCount(2)

    table.setHorizontalHeaderLabels(["Tarih", "Not"])

    for i, note in enumerate(notes):
        table.setItem(i, 0, QTableWidgetItem(str(note['date'])))
        table.setItem(i, 1, QTableWidgetItem(str(note['notes'])))

    add_user_notes_button = QPushButton('Not Ekle')
    add_user_notes_button.clicked.connect(lambda: add_user_notes_dialog(stack, user))

    box.addWidget(add_user_notes_button)
    box.addWidget(table)

    widget.setLayout(box)
    return widget

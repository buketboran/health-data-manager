import mysql.connector

db_connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="healthmate"
)


def login(password, username):
    cursor = db_connection.cursor()
    cursor.callproc('login', [username, password])
    result = cursor.stored_results().__next__().fetchone()
    return result


def register(email, firstname, lastname, password, role, username):
    cursor = db_connection.cursor()
    cursor.callproc('register', [username, password, email, firstname, lastname, role])
    db_connection.commit()


def get_user_blood_pressures(user_id):
    cursor = db_connection.cursor()
    cursor.callproc('get_user_blood_pressures', [user_id])
    result = cursor.stored_results().__next__()
    blood_pressures = []
    for row in result:
        blood_pressures.append({
            'id': row[0],
            'user_id': row[1],
            'systolic': row[2],
            'diastolic': row[3],
            'date': row[4]
        })
    return blood_pressures


def get_user_blood_sugars(user_id):
    cursor = db_connection.cursor()
    cursor.callproc('get_user_blood_sugars', [user_id])
    result = cursor.stored_results().__next__()
    blood_sugars = []
    for row in result:
        blood_sugars.append({
            'id': row[0],
            'user_id': row[1],
            'blood_sugar': row[2],
            'date': row[3]
        })
    return blood_sugars


def get_user_heart_rates(user_id):
    cursor = db_connection.cursor()
    cursor.callproc('get_user_heart_rates', [user_id])
    result = cursor.stored_results().__next__()
    heart_rates = []
    for row in result:
        heart_rates.append({
            'id': row[0],
            'user_id': row[1],
            'heart_rate': row[2],
            'date': row[3]
        })
    return heart_rates


def get_user_weight(user_id):
    cursor = db_connection.cursor()
    cursor.callproc('get_user_weight', [user_id])
    result = cursor.stored_results().__next__()
    weights = []
    for row in result:
        weights.append({
            'id': row[0],
            'user_id': row[1],
            'weight': row[2],
            'date': row[3]
        })
    return weights


def get_user_notes(user_id):
    cursor = db_connection.cursor()
    cursor.callproc('get_user_notes', [user_id])
    result = cursor.stored_results().__next__()
    notes = []
    for row in result:
        notes.append({
            'id': row[0],
            'user_id': row[1],
            'notes': row[2],
            'date': row[3]
        })
    return notes


def add_blood_pressure(user_id, systolic, diastolic):
    cursor = db_connection.cursor()
    cursor.callproc('add_blood_pressure_reading', [user_id, systolic, diastolic])
    db_connection.commit()


def add_blood_sugar(user_id, blood_sugar):
    cursor = db_connection.cursor()
    cursor.callproc('add_blood_sugar_reading', [user_id, blood_sugar])
    db_connection.commit()


def add_heart_rate(user_id, heart_rate):
    cursor = db_connection.cursor()
    cursor.callproc('add_heart_rate_reading', [user_id, heart_rate])
    db_connection.commit()


def add_weight(user_id, weight):
    cursor = db_connection.cursor()
    cursor.callproc('add_weight_reading', [user_id, weight])
    db_connection.commit()


def add_user_notes(user_id, notes):
    cursor = db_connection.cursor()
    cursor.callproc('add_note', [user_id, notes])
    db_connection.commit()

style_sheet = ''

with open('style.css', 'r') as f:
    style_sheet = f.read()